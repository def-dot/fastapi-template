--
-- PostgreSQL database dump
--

\restrict A28awD3YC03EFFPnH7pg2Uk2NqXiOiOsTIgO7QAe0TDjC3I6rQ5UvBLAeQWxXP2

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    description character varying,
    owner_id integer NOT NULL
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.items_id_seq OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(120) NOT NULL,
    hashed_password character varying(128) NOT NULL,
    is_active boolean NOT NULL,
    description character varying(255)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
1ac4c4757316
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, title, description, owner_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, hashed_password, is_active, description) FROM stdin;
1	admin	admin@example.com	$argon2id$v=19$m=65536,t=3,p=4$9zD3JuQWpvyB7P9Cr7jtjQ$YC3ASjcuvjXcCvkLSlWrB/HkAe+56VOj1W+AYvIOPyM	t	\N
2	defdot	defdot@test.com	$argon2id$v=19$m=65536,t=3,p=4$k209upmUMp6hFDyo+1tL9A$Uiilf9m/pe7ShA61qAQc2MB1NEdlrqOP5Lga7R3z5Es	t	\N
3	defdot1	defdot1@test.com	$argon2id$v=19$m=65536,t=3,p=4$gF9y/qTL988wTs65373iXA$edKNirC4Mct5AAFMnJisZiSZHlLScfBVjSsUUW2AFxY	t	\N
4	defdot2	defdot2@test.com	$argon2id$v=19$m=65536,t=3,p=4$eeZVKWQlphUoApVAKDhg3A$wY6+e7pnhAiuRLGydvy9UvaZKdAkCzipJyH7gfsOJWY	t	\N
5	defdot3	defdot3@test.com	$argon2id$v=19$m=65536,t=3,p=4$mDP93avtIdFeykjtSRrwsQ$ZBWHp3nFKW4ySRmbvI2VQK5nvoHl7nIFxHt1utR+5NE	t	\N
6	defdot4	defdot4@test.com	$argon2id$v=19$m=65536,t=3,p=4$n01A7dGNDhdc1zkOi0ARQw$uuUxxiMNQHUgrBg3VfxWKSpsqqnnSq4ldljFacz2IMY	t	\N
7	defdot5	defdot5@test.com	$argon2id$v=19$m=65536,t=3,p=4$5TDYNgdDzLRh4fBFwTjETg$W/iDR3Wjc4zmEmUFRyGS8vR1KdiY+slKthO4+WuDk2w	t	\N
8	defdot6	defdot6@test.com	$argon2id$v=19$m=65536,t=3,p=4$Hx8bwkDr2gphnQo+eY5SuA$3sPXPwltEQQMWUaiOJcPegcEmBZ4xcppQCx9nMasqgM	t	\N
9	defdot7	defdot7@test.com	$argon2id$v=19$m=65536,t=3,p=4$D4fHTVPO0Cm+9z5vjcoMzQ$Z7NHjcNn4EG2imWs48Pk5Uq551DHVsPWW56qWSEAIbM	t	\N
10	defdot8	defdot8@test.com	$argon2id$v=19$m=65536,t=3,p=4$t/Nr3DGFbied0r0TZPWh3w$+yJYUy4iGiKrJ4pESweGE3pjCmLClozcNAvyd5C9oNo	t	\N
\.


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: items items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict A28awD3YC03EFFPnH7pg2Uk2NqXiOiOsTIgO7QAe0TDjC3I6rQ5UvBLAeQWxXP2

